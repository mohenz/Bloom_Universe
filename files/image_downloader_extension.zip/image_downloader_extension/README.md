# Page Image Picker

현재 Chrome 탭에 실제로 로드된 이미지를 썸네일로 확인하고, 선택한 이미지만 다운로드하는 Manifest V3 확장프로그램입니다.

## 설치

1. Chrome 주소창에서 `chrome://extensions`를 엽니다.
2. 개발자 모드를 켭니다.
3. `압축해제된 확장 프로그램을 로드합니다`를 선택합니다.
4. `D:\workspace\image_downloader_extension` 폴더를 지정합니다.

## 사용

1. 이미지가 있는 웹페이지를 엽니다.
2. 필요한 지연 로딩 이미지가 보이도록 페이지를 먼저 스크롤합니다.
3. Page Image Picker 아이콘을 누릅니다.
4. 다운로드할 이미지를 선택하고 `선택 이미지 다운로드`를 누릅니다.

파일은 기본 다운로드 폴더의 `Page Image Picker/<페이지 제목>/` 아래에 저장됩니다.

## 제한

- 현재 DOM에 정상 로드된 `<img>`만 수집합니다.
- CSS 배경 이미지, 동영상 프레임, 로드되지 않은 지연 이미지, `blob:` 및 `data:` 이미지는 제외합니다.
- 사이트의 다운로드 제한과 저작권 정책을 준수해야 합니다.

## 검증

```powershell
node verify.mjs
```
