(() => {
  const images = new Map();

  for (const image of document.images) {
    if (!image.complete || image.naturalWidth === 0 || image.naturalHeight === 0) continue;

    const source = image.currentSrc || image.src;
    if (!source) continue;

    let url;
    try {
      url = new URL(source, document.baseURI);
    } catch {
      continue;
    }

    if (url.protocol !== "http:" && url.protocol !== "https:") continue;

    const existing = images.get(url.href);
    const candidate = {
      url: url.href,
      alt: image.alt?.trim() || "",
      width: image.naturalWidth,
      height: image.naturalHeight
    };

    if (!existing || candidate.width * candidate.height > existing.width * existing.height) {
      images.set(url.href, candidate);
    }
  }

  return {
    pageTitle: document.title || "page",
    pageUrl: location.href,
    images: [...images.values()]
  };
})();
