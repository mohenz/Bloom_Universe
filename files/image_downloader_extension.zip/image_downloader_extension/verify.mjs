import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { spawnSync } from "node:child_process";
import vm from "node:vm";

const files = ["popup.js", "content.js", "background.js"];
for (const file of files) {
  const result = spawnSync(process.execPath, ["--check", file], { encoding: "utf8" });
  assert.equal(result.status, 0, result.stderr);
}

const manifest = JSON.parse(readFileSync("manifest.json", "utf8"));
assert.equal(manifest.manifest_version, 3);
assert.deepEqual([...manifest.permissions].sort(), ["activeTab", "downloads", "scripting"]);

const contentContext = vm.createContext({
  URL,
  location: { href: "https://example.com/chapter-1/" },
  document: {
    title: "Chapter 1",
    baseURI: "https://example.com/chapter-1/",
    images: [
      { complete: true, naturalWidth: 800, naturalHeight: 1200, currentSrc: "https://cdn.example.com/01.webp", src: "", alt: "Page 1" },
      { complete: true, naturalWidth: 400, naturalHeight: 600, currentSrc: "https://cdn.example.com/01.webp", src: "", alt: "duplicate" },
      { complete: false, naturalWidth: 0, naturalHeight: 0, currentSrc: "", src: "https://cdn.example.com/lazy.jpg", alt: "lazy" },
      { complete: true, naturalWidth: 20, naturalHeight: 20, currentSrc: "data:image/png;base64,AA==", src: "", alt: "inline" }
    ]
  }
});
const collected = vm.runInContext(readFileSync("content.js", "utf8"), contentContext);
assert.equal(collected.images.length, 1);
assert.equal(collected.images[0].url, "https://cdn.example.com/01.webp");
assert.equal(collected.images[0].width, 800);

const backgroundContext = vm.createContext({
  URL,
  chrome: {
    downloads: { download: async () => 1 },
    runtime: { onMessage: { addListener: () => {} } }
  }
});
vm.runInContext(readFileSync("background.js", "utf8"), backgroundContext);
assert.equal(vm.runInContext("safeName('a/b:c', 'fallback')", backgroundContext), "a b c");
assert.equal(vm.runInContext("imageName('https://example.com/path/page.webp', 0)", backgroundContext), "page.webp");

console.log("PASS: manifest, syntax, image collection, filename handling");
