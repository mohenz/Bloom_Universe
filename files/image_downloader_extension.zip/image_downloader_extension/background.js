function safeName(value, fallback) {
  const cleaned = String(value || "")
    .replace(/[<>:"/\\|?*\u0000-\u001f]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/[. ]+$/g, "");
  return (cleaned || fallback).slice(0, 80);
}

function imageName(url, index) {
  const pathname = new URL(url).pathname;
  const rawName = decodeURIComponent(pathname.split("/").pop() || "");
  const name = safeName(rawName, `image-${String(index + 1).padStart(3, "0")}`);
  return /^.+\.(?:avif|bmp|gif|jpe?g|png|svg|webp)$/i.test(name)
    ? name
    : `${name}.jpg`;
}

async function downloadImages(message) {
  const folder = safeName(message.pageTitle, "page-images");
  let completed = 0;
  const failures = [];

  for (const [index, image] of message.images.entries()) {
    try {
      await chrome.downloads.download({
        url: image.url,
        filename: `Page Image Picker/${folder}/${String(index + 1).padStart(3, "0")}-${imageName(image.url, index)}`,
        conflictAction: "uniquify",
        saveAs: false
      });
      completed += 1;
    } catch (error) {
      failures.push({ url: image.url, reason: error.message || "다운로드 실패" });
    }
  }

  return { completed, failures };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "DOWNLOAD_IMAGES") return false;
  downloadImages(message).then(sendResponse);
  return true;
});
