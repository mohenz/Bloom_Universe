const elements = {
  status: document.getElementById("status"),
  list: document.getElementById("imageList"),
  scan: document.getElementById("scanButton"),
  selectAll: document.getElementById("selectAllButton"),
  clear: document.getElementById("clearButton"),
  download: document.getElementById("downloadButton")
};

let pageTitle = "page-images";
let images = [];

function selectedImages() {
  return [...elements.list.querySelectorAll("input[type=checkbox]:checked")]
    .map((input) => images[Number(input.value)])
    .filter(Boolean);
}

function updateSelectionStatus() {
  const selected = selectedImages().length;
  elements.status.textContent = `전체 ${images.length}개 · 선택 ${selected}개`;
  elements.download.disabled = selected === 0;
}

function createImageCard(image, index) {
  const label = document.createElement("label");
  label.className = "image-card";

  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.value = String(index);
  checkbox.addEventListener("change", updateSelectionStatus);

  const preview = document.createElement("img");
  preview.src = image.url;
  preview.alt = image.alt || `이미지 ${index + 1}`;
  preview.loading = "lazy";

  const meta = document.createElement("span");
  meta.className = "image-meta";

  const size = document.createElement("strong");
  size.textContent = `${image.width} × ${image.height}`;

  const host = document.createElement("small");
  host.textContent = new URL(image.url).hostname;
  host.title = image.url;

  meta.append(size, host);
  label.append(checkbox, preview, meta);
  return label;
}

function render() {
  elements.list.replaceChildren(...images.map(createImageCard));
  if (!images.length) {
    const empty = document.createElement("p");
    empty.className = "empty";
    empty.textContent = "현재 페이지에 로드된 이미지가 없습니다. 페이지를 스크롤한 뒤 다시 읽어 주세요.";
    elements.list.append(empty);
  }
  updateSelectionStatus();
}

async function scanPage() {
  elements.scan.disabled = true;
  elements.status.textContent = "페이지를 확인하는 중입니다.";

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error("활성 탭을 찾을 수 없습니다.");

    const [result] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });

    pageTitle = result?.result?.pageTitle || tab.title || "page-images";
    images = result?.result?.images || [];
    render();
  } catch (error) {
    images = [];
    elements.list.replaceChildren();
    elements.status.textContent = error.message || "이 페이지에서는 이미지를 읽을 수 없습니다.";
    elements.download.disabled = true;
  } finally {
    elements.scan.disabled = false;
  }
}

elements.scan.addEventListener("click", scanPage);
elements.selectAll.addEventListener("click", () => {
  elements.list.querySelectorAll("input[type=checkbox]").forEach((input) => { input.checked = true; });
  updateSelectionStatus();
});
elements.clear.addEventListener("click", () => {
  elements.list.querySelectorAll("input[type=checkbox]").forEach((input) => { input.checked = false; });
  updateSelectionStatus();
});
elements.download.addEventListener("click", async () => {
  const selected = selectedImages();
  if (!selected.length) return;

  elements.download.disabled = true;
  elements.download.textContent = "다운로드 중…";
  const result = await chrome.runtime.sendMessage({ type: "DOWNLOAD_IMAGES", pageTitle, images: selected });
  const failed = result?.failures?.length || 0;
  elements.status.textContent = `완료 ${result?.completed || 0}개${failed ? ` · 실패 ${failed}개` : ""}`;
  elements.download.textContent = "선택 이미지 다운로드";
  elements.download.disabled = false;
});

scanPage();
