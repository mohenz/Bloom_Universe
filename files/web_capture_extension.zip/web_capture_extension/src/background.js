const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const captureStore = new Map();

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.action === "get-capture") {
    const payload = captureStore.get(message.id);
    captureStore.delete(message.id);
    sendResponse({ ok: Boolean(payload), payload });
    return false;
  }

  handleAction(message.action)
    .then(() => sendResponse({ ok: true }))
    .catch((error) => sendResponse({ ok: false, error: error.message }));
  return true;
});

async function handleAction(action) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || tab.url?.startsWith("chrome://")) {
    throw new Error("이 페이지는 캡처할 수 없습니다.");
  }

  if (action === "capture-visible") {
    await captureVisible(tab);
    return;
  }
  if (action === "capture-area") {
    await captureArea(tab);
    return;
  }
  if (action === "capture-full") {
    await captureFullPage(tab);
    return;
  }
  throw new Error("알 수 없는 작업입니다.");
}

async function ensureContentScript(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { action: "page-metrics" });
  } catch (_error) {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["src/content.js"] });
  }
}

async function tabMessage(tabId, message) {
  await ensureContentScript(tabId);
  return chrome.tabs.sendMessage(tabId, message);
}

async function captureVisibleTab(tab) {
  return chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
}

function positionsForRange(start, size, viewportSize, maxSize) {
  const end = Math.min(maxSize, start + size);
  const maxScroll = Math.max(0, maxSize - viewportSize);
  const positions = [];
  for (let pos = start; pos < end; pos += viewportSize) {
    positions.push(Math.min(pos, maxScroll));
  }
  positions.push(Math.min(Math.max(0, end - viewportSize), maxScroll));
  return [...new Set(positions.map((pos) => Math.max(0, Math.round(pos))))];
}

function intersect(a, b) {
  const left = Math.max(a.left, b.left);
  const top = Math.max(a.top, b.top);
  const right = Math.min(a.left + a.width, b.left + b.width);
  const bottom = Math.min(a.top + a.height, b.top + b.height);
  if (right <= left || bottom <= top) return null;
  return { left, top, width: right - left, height: bottom - top };
}

async function captureDocumentArea(tab, rect, metrics) {
  const xPositions = positionsForRange(rect.left, rect.width, metrics.viewportWidth, metrics.fullWidth);
  const yPositions = positionsForRange(rect.top, rect.height, metrics.viewportHeight, metrics.fullHeight);
  let targetCanvas = null;
  let targetCtx = null;
  let scaleX = 1;
  let scaleY = 1;

  for (const y of yPositions) {
    for (const x of xPositions) {
      const visibleMetrics = await tabMessage(tab.id, { action: "scroll-to", x, y });
      await wait(300);
      const image = await captureVisibleTab(tab);
      const sourceBlob = await (await fetch(image)).blob();
      const source = await createImageBitmap(sourceBlob);
      scaleX = source.width / Math.max(1, visibleMetrics.viewportWidth);
      scaleY = source.height / Math.max(1, visibleMetrics.viewportHeight);

      if (!targetCanvas) {
        targetCanvas = new OffscreenCanvas(Math.max(1, Math.round(rect.width * scaleX)), Math.max(1, Math.round(rect.height * scaleY)));
        targetCtx = targetCanvas.getContext("2d");
      }

      const viewportRect = {
        left: visibleMetrics.x,
        top: visibleMetrics.y,
        width: visibleMetrics.viewportWidth,
        height: visibleMetrics.viewportHeight
      };
      const part = intersect(rect, viewportRect);
      if (!part) continue;

      targetCtx.drawImage(
        source,
        Math.round((part.left - viewportRect.left) * scaleX),
        Math.round((part.top - viewportRect.top) * scaleY),
        Math.round(part.width * scaleX),
        Math.round(part.height * scaleY),
        Math.round((part.left - rect.left) * scaleX),
        Math.round((part.top - rect.top) * scaleY),
        Math.round(part.width * scaleX),
        Math.round(part.height * scaleY)
      );
    }
  }

  if (!targetCanvas) throw new Error("선택 영역을 캡처하지 못했습니다.");
  const blob = await targetCanvas.convertToBlob({ type: "image/png" });
  return blobToDataUrl(blob);
}

async function blobToDataUrl(blob) {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  let binary = "";
  for (let index = 0; index < bytes.length; index += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(index, index + 0x8000));
  }
  return `data:${blob.type || "image/png"};base64,${btoa(binary)}`;
}

function filename(title, ext) {
  const safeTitle = (title || "capture").replace(/[\\/:*?"<>|]+/g, "-").trim().slice(0, 80) || "capture";
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  return `${safeTitle}-${stamp}.${ext}`;
}

async function openEditor(payload) {
  const id = crypto.randomUUID();
  captureStore.set(id, payload);
  await chrome.tabs.create({ url: chrome.runtime.getURL(`src/editor.html?id=${id}`) });
}

async function captureVisible(tab) {
  const metrics = await tabMessage(tab.id, { action: "page-metrics" });
  const image = await captureVisibleTab(tab);
  await openEditor({
    mode: "single",
    image,
    meta: metrics,
    filenameBase: filename(metrics.title, "png")
  });
}

async function captureArea(tab) {
  const rect = await tabMessage(tab.id, { action: "select-area" });
  if (!rect) throw new Error("선택 영역이 없습니다.");
  const metrics = await tabMessage(tab.id, { action: "page-metrics" });
  const croppedImage = await captureDocumentArea(tab, rect, metrics);
  await tabMessage(tab.id, { action: "scroll-to", x: metrics.x, y: metrics.y });
  await openEditor({
    mode: "single",
    image: croppedImage,
    meta: metrics,
    filenameBase: filename(metrics.title, "png")
  });
}

async function captureFullPage(tab) {
  const metrics = await tabMessage(tab.id, { action: "page-metrics" });
  const maxHeight = Math.min(metrics.fullHeight, 30000);
  const positions = [];
  for (let y = 0; y < maxHeight; y += metrics.viewportHeight) {
    positions.push(Math.min(y, Math.max(0, maxHeight - metrics.viewportHeight)));
  }
  const uniquePositions = [...new Set(positions)];
  const segments = [];

  for (const y of uniquePositions) {
    await tabMessage(tab.id, { action: "scroll-to", x: 0, y });
    await wait(350);
    segments.push({ y, image: await captureVisibleTab(tab) });
  }

  await tabMessage(tab.id, { action: "scroll-to", x: metrics.x, y: metrics.y });
  await openEditor({
    mode: "full",
    segments,
    meta: { ...metrics, fullHeight: maxHeight },
    filenameBase: filename(metrics.title, "png")
  });
}
