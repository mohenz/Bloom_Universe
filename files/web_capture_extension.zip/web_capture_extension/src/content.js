function pageMetrics() {
  const body = document.body;
  const doc = document.documentElement;
  return {
    url: location.href,
    title: document.title || location.hostname || "capture",
    x: window.scrollX,
    y: window.scrollY,
    viewportWidth: window.innerWidth,
    viewportHeight: window.innerHeight,
    fullWidth: Math.max(body.scrollWidth, body.offsetWidth, doc.clientWidth, doc.scrollWidth, doc.offsetWidth),
    fullHeight: Math.max(body.scrollHeight, body.offsetHeight, doc.clientHeight, doc.scrollHeight, doc.offsetHeight),
    dpr: window.devicePixelRatio || 1
  };
}

function scrollToPosition(x, y) {
  window.scrollTo(x, y);
  return pageMetrics();
}

function startSelection() {
  return new Promise((resolve) => {
    const overlay = document.createElement("div");
    const box = document.createElement("div");
    let startX = 0;
    let startY = 0;
    let lastClientX = 0;
    let lastClientY = 0;
    let active = false;
    let scrollTimer = 0;

    overlay.style.cssText = [
      "position:fixed",
      "inset:0",
      "z-index:2147483647",
      "cursor:crosshair",
      "background:rgba(15,23,42,.16)"
    ].join(";");
    box.style.cssText = [
      "position:fixed",
      "border:2px solid #2563eb",
      "background:rgba(37,99,235,.14)",
      "display:none",
      "pointer-events:none"
    ].join(";");
    overlay.appendChild(box);
    document.documentElement.appendChild(overlay);

    function documentPoint(event) {
      return {
        x: event.clientX + window.scrollX,
        y: event.clientY + window.scrollY
      };
    }

    function updateBox(currentX, currentY) {
      const left = Math.min(startX, currentX);
      const top = Math.min(startY, currentY);
      const width = Math.abs(currentX - startX);
      const height = Math.abs(currentY - startY);
      box.style.left = `${left - window.scrollX}px`;
      box.style.top = `${top - window.scrollY}px`;
      box.style.width = `${width}px`;
      box.style.height = `${height}px`;
    }

    function startAutoScroll() {
      scrollTimer = window.setInterval(() => {
        if (!active) return;
        let dx = 0;
        let dy = 0;
        const edge = 48;
        const speed = 28;
        if (lastClientX < edge) dx = -speed;
        if (lastClientX > window.innerWidth - edge) dx = speed;
        if (lastClientY < edge) dy = -speed;
        if (lastClientY > window.innerHeight - edge) dy = speed;
        if (!dx && !dy) return;
        window.scrollBy(dx, dy);
        updateBox(lastClientX + window.scrollX, lastClientY + window.scrollY);
      }, 30);
    }

    function cleanup(result) {
      window.clearInterval(scrollTimer);
      overlay.remove();
      resolve(result);
    }

    overlay.addEventListener("mousedown", (event) => {
      active = true;
      const point = documentPoint(event);
      startX = point.x;
      startY = point.y;
      lastClientX = event.clientX;
      lastClientY = event.clientY;
      box.style.display = "block";
      startAutoScroll();
    });

    overlay.addEventListener("mousemove", (event) => {
      if (!active) return;
      lastClientX = event.clientX;
      lastClientY = event.clientY;
      const point = documentPoint(event);
      updateBox(point.x, point.y);
    });

    overlay.addEventListener("mouseup", (event) => {
      if (!active) return;
      active = false;
      const point = documentPoint(event);
      const left = Math.min(startX, point.x);
      const top = Math.min(startY, point.y);
      const width = Math.abs(point.x - startX);
      const height = Math.abs(point.y - startY);
      cleanup(width > 4 && height > 4 ? { left, top, width, height } : null);
    });

    overlay.addEventListener("keydown", (event) => {
      if (event.key === "Escape") cleanup(null);
    });
    overlay.tabIndex = 0;
    overlay.focus();
  });
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.action === "page-metrics") {
    sendResponse(pageMetrics());
    return;
  }
  if (message.action === "scroll-to") {
    sendResponse(scrollToPosition(message.x || 0, message.y || 0));
    return;
  }
  if (message.action === "select-area") {
    startSelection().then(sendResponse);
    return true;
  }
});
