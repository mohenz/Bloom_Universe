const statusEl = document.getElementById("status");
const buttons = Array.from(document.querySelectorAll("button"));

function setBusy(message) {
  statusEl.textContent = message;
  buttons.forEach((button) => {
    button.disabled = Boolean(message);
  });
}

async function send(action) {
  setBusy("처리 중");
  try {
    const response = await chrome.runtime.sendMessage({ action });
    if (!response?.ok) {
      throw new Error(response?.error || "캡처에 실패했습니다.");
    }
    window.close();
  } catch (error) {
    statusEl.textContent = error.message;
    buttons.forEach((button) => {
      button.disabled = false;
    });
  }
}

document.getElementById("capture-visible").addEventListener("click", () => {
  send("capture-visible");
});

document.getElementById("capture-full").addEventListener("click", () => {
  send("capture-full");
});

document.getElementById("capture-area").addEventListener("click", () => {
  send("capture-area");
});
