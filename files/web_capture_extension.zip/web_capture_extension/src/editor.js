const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d", { willReadFrequently: true });
const statusEl = document.getElementById("status");
const colorEl = document.getElementById("color");
const sizeEl = document.getElementById("size");
let tool = "rect";
let start = null;
let preview = null;
let history = [];
let pendingCrop = null;
let filenameBase = "capture.png";

function setStatus(message) {
  statusEl.textContent = message;
}

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = reject;
    image.src = src;
  });
}

function dataUrlToBlob(dataUrl) {
  const [header, body] = dataUrl.split(",");
  const mime = header.match(/:(.*?);/)?.[1] || "image/png";
  const binary = atob(body);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }
  return new Blob([bytes], { type: mime });
}

function download(dataUrl, ext) {
  const link = document.createElement("a");
  link.href = dataUrl;
  link.download = filenameBase.replace(/\.[a-z]+$/i, `.${ext}`);
  link.click();
}

function pushHistory() {
  if (!canvas.width || !canvas.height) return;
  history.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
  if (history.length > 12) history.shift();
}

function restorePreview() {
  if (preview) ctx.putImageData(preview, 0, 0);
}

function clearCropPreview() {
  if (!pendingCrop) return;
  const current = history.at(-1);
  if (current) ctx.putImageData(current, 0, 0);
  pendingCrop = null;
}

function point(event) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: Math.round((event.clientX - rect.left) * (canvas.width / rect.width)),
    y: Math.round((event.clientY - rect.top) * (canvas.height / rect.height))
  };
}

function rectFromPoints(a, b) {
  return {
    x: Math.min(a.x, b.x),
    y: Math.min(a.y, b.y),
    width: Math.abs(a.x - b.x),
    height: Math.abs(a.y - b.y)
  };
}

function drawArrow(from, to) {
  const size = Number(sizeEl.value);
  const angle = Math.atan2(to.y - from.y, to.x - from.x);
  ctx.strokeStyle = colorEl.value;
  ctx.fillStyle = colorEl.value;
  ctx.lineWidth = size;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(from.x, from.y);
  ctx.lineTo(to.x, to.y);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(to.x, to.y);
  ctx.lineTo(to.x - size * 4 * Math.cos(angle - Math.PI / 6), to.y - size * 4 * Math.sin(angle - Math.PI / 6));
  ctx.lineTo(to.x - size * 4 * Math.cos(angle + Math.PI / 6), to.y - size * 4 * Math.sin(angle + Math.PI / 6));
  ctx.closePath();
  ctx.fill();
}

function drawRect(rect) {
  ctx.strokeStyle = colorEl.value;
  ctx.lineWidth = Number(sizeEl.value);
  ctx.strokeRect(rect.x, rect.y, rect.width, rect.height);
}

function blurRect(rect) {
  if (rect.width < 2 || rect.height < 2) return;
  const image = ctx.getImageData(rect.x, rect.y, rect.width, rect.height);
  const temp = document.createElement("canvas");
  const tempCtx = temp.getContext("2d");
  temp.width = Math.max(1, Math.floor(rect.width / 10));
  temp.height = Math.max(1, Math.floor(rect.height / 10));
  tempCtx.putImageData(image, 0, 0);
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(temp, rect.x, rect.y, temp.width, temp.height, rect.x, rect.y, rect.width, rect.height);
  ctx.imageSmoothingEnabled = true;
}

function crop(rect) {
  if (rect.width < 4 || rect.height < 4) return;
  const image = ctx.getImageData(rect.x, rect.y, rect.width, rect.height);
  canvas.width = rect.width;
  canvas.height = rect.height;
  ctx.putImageData(image, 0, 0);
}

function drawPreview(current) {
  restorePreview();
  const rect = rectFromPoints(start, current);
  if (tool === "rect" || tool === "crop") drawRect(rect);
  if (tool === "arrow") drawArrow(start, current);
  if (tool === "blur") {
    ctx.fillStyle = "rgba(37, 99, 235, .18)";
    ctx.fillRect(rect.x, rect.y, rect.width, rect.height);
    drawRect(rect);
  }
}

async function renderPayload(payload) {
  filenameBase = payload.filenameBase || "capture.png";
  const meta = payload.meta || {};

  if (payload.mode === "full") {
    canvas.width = Math.round(meta.viewportWidth * meta.dpr);
    canvas.height = Math.round(meta.fullHeight * meta.dpr);
    for (const segment of payload.segments) {
      const image = await loadImage(segment.image);
      ctx.drawImage(image, 0, Math.round(segment.y * meta.dpr));
    }
  } else {
    const image = await loadImage(payload.image);
    canvas.width = image.naturalWidth;
    canvas.height = image.naturalHeight;
    ctx.drawImage(image, 0, 0);
  }
  pushHistory();
  setStatus("준비됨");
}

async function init() {
  const id = new URLSearchParams(location.search).get("id");
  if (!id) {
    setStatus("데이터 없음");
    return;
  }
  const data = await chrome.runtime.sendMessage({ action: "get-capture", id });
  const payload = data?.payload;
  if (!payload) {
    setStatus("캡처 데이터 만료");
    return;
  }
  await renderPayload(payload);
}

document.querySelectorAll("[data-tool]").forEach((button) => {
  button.addEventListener("click", () => {
    if (button.dataset.tool !== "crop") clearCropPreview();
    tool = button.dataset.tool;
    document.querySelectorAll("[data-tool]").forEach((item) => item.classList.toggle("active", item === button));
  });
});

canvas.addEventListener("mousedown", (event) => {
  if (!canvas.width) return;
  start = point(event);
  if (tool !== "crop") clearCropPreview();
  if (tool === "text") {
    const text = prompt("추가할 텍스트를 입력하세요.");
    if (!text) return;
    pushHistory();
    ctx.fillStyle = colorEl.value;
    ctx.font = `${Math.max(18, Number(sizeEl.value) * 5)}px system-ui, sans-serif`;
    ctx.fillText(text, start.x, start.y);
    return;
  }
  preview = ctx.getImageData(0, 0, canvas.width, canvas.height);
});

canvas.addEventListener("mousemove", (event) => {
  if (!start || !preview || tool === "text") return;
  drawPreview(point(event));
});

canvas.addEventListener("mouseup", (event) => {
  if (!start || !preview || tool === "text") {
    start = null;
    preview = null;
    return;
  }
  const end = point(event);
  const rect = rectFromPoints(start, end);
  restorePreview();
  if (tool === "crop") pendingCrop = rect;
  if (tool === "crop") {
    drawRect(rect);
  } else {
    pushHistory();
    if (tool === "rect") drawRect(rect);
    if (tool === "arrow") drawArrow(start, end);
    if (tool === "blur") blurRect(rect);
  }
  start = null;
  preview = null;
});

document.getElementById("apply-crop").addEventListener("click", () => {
  if (!pendingCrop) {
    setStatus("자르기 영역을 먼저 드래그하세요.");
    return;
  }
  const current = history.at(-1);
  if (current) ctx.putImageData(current, 0, 0);
  crop(pendingCrop);
  pushHistory();
  pendingCrop = null;
  setStatus("자르기 적용됨");
});

document.getElementById("undo").addEventListener("click", () => {
  if (history.length < 2) return;
  pendingCrop = null;
  history.pop();
  const image = history.at(-1);
  canvas.width = image.width;
  canvas.height = image.height;
  ctx.putImageData(image, 0, 0);
});

document.getElementById("save-png").addEventListener("click", () => {
  clearCropPreview();
  download(canvas.toDataURL("image/png"), "png");
});

document.getElementById("save-jpeg").addEventListener("click", () => {
  clearCropPreview();
  download(canvas.toDataURL("image/jpeg", 0.92), "jpg");
});

document.getElementById("copy").addEventListener("click", async () => {
  clearCropPreview();
  const blob = dataUrlToBlob(canvas.toDataURL("image/png"));
  await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
  setStatus("복사됨");
});

document.getElementById("print").addEventListener("click", () => {
  clearCropPreview();
  const win = window.open("", "_blank");
  const image = canvas.toDataURL("image/png");
  win.document.write(`<!doctype html><title>Print</title><img src="${image}" style="max-width:100%;width:100%">`);
  win.document.close();
  win.focus();
  win.print();
});

init().catch((error) => setStatus(error.message));
