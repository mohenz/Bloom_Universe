# Web Capture Extension

웹 페이지 전체 캡처, 편집, 주석, PDF/이미지 저장을 목표로 하는 브라우저 확장프로그램 프로젝트입니다.

## 현재 상태
- Manifest V3 Chrome 확장프로그램 MVP 구현 완료
- 보이는 영역, 전체 페이지, 선택 영역 캡처 지원
- 편집기에서 텍스트, 화살표, 사각형, 흐림, 자르기, 실행 취소 지원
- PNG/JPEG 저장, 클립보드 복사, 인쇄/PDF 저장 흐름 지원

## 핵심 문서
- `docs/requirements.md`

## 실행 / 검증
- run: Chrome 또는 Chromium 기반 브라우저에서 `D:\workspace\web_capture_extension`를 압축해제된 확장 프로그램으로 로드
- verify: `npm.cmd run check:syntax`

## 사용 방법
1. Chrome에서 `chrome://extensions`를 연다.
2. 개발자 모드를 켠다.
3. `압축해제된 확장 프로그램 로드`에서 이 폴더를 선택한다.
4. 확장 아이콘에서 캡처 방식을 선택한다.

## 현재 제한
- PDF는 별도 PDF 라이브러리 없이 인쇄 화면을 열어 Chrome의 `PDF로 저장`을 사용한다.
- 링크 포함 PDF, Gmail 직접 전송, OCR, 모든 탭 단일 PDF는 후순위 기능이다.
- 매우 긴 페이지는 브라우저 캔버스/메모리 제한에 영향을 받을 수 있다.
