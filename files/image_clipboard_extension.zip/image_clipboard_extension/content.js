(() => {
  if (window.top !== window && window.innerWidth < 80) return;

  const HOVER_DELAY = 350; // 마우스를 올린 뒤 확인창이 뜨기까지(ms)
  const HIDE_DELAY = 350; // 이미지/확인창을 벗어난 뒤 사라지기까지(ms)
  const MIN_SIZE = 48; // 이보다 작은 이미지(아이콘 등)는 무시

  // ---- Shadow DOM UI ----
  const host = document.createElement("div");
  host.style.cssText = "all:initial;position:fixed;z-index:2147483647;top:0;left:0;";
  const root = host.attachShadow({ mode: "closed" });
  root.innerHTML = `
    <style>
      .bubble{position:fixed;display:none;align-items:center;gap:8px;padding:16px 20px;
        background:#18181b;color:#fafafa;border-radius:20px;font:26px/1.2 system-ui,"Malgun Gothic",sans-serif;
        box-shadow:0 8px 32px rgba(0,0,0,.35);white-space:nowrap}
      .bubble.show{display:flex}
      button{font:inherit;border:0;border-radius:12px;padding:10px 20px;cursor:pointer}
      .ok{background:#fafafa;color:#18181b;font-weight:600}
      .toast{position:fixed;right:16px;bottom:16px;display:none;padding:10px 14px;border-radius:10px;
        background:#18181b;color:#fafafa;font:13px/1.3 system-ui,"Malgun Gothic",sans-serif;
        box-shadow:0 4px 16px rgba(0,0,0,.35)}
      .toast.show{display:block}
      .toast.err{background:#b91c1c}
    </style>
    <div class="bubble" id="bubble">
      <button class="ok" id="ok">복사</button>
    </div>
    <div class="bubble" id="pbubble">
      <button class="ok" id="paste">붙여넣기</button>
    </div>
    <div class="toast" id="toast"></div>`;
  const bubble = root.getElementById("bubble");
  const toast = root.getElementById("toast");
  document.documentElement.appendChild(host);

  let current = null; // 확인창이 가리키는 img
  let dismissed = null; // 취소/복사 후 마우스가 벗어나기 전까지 다시 안 띄울 img
  let showTimer = 0;
  let hideTimer = 0;
  let toastTimer = 0;

  const isCandidate = (el) => {
    if (!(el instanceof HTMLImageElement)) return false;
    const r = el.getBoundingClientRect();
    return r.width >= MIN_SIZE && r.height >= MIN_SIZE && !!(el.currentSrc || el.src);
  };

  function position(img) {
    const r = img.getBoundingClientRect();
    bubble.classList.add("show");
    const b = bubble.getBoundingClientRect();
    // 이미지 중앙 (화면 밖으로 잘린 이미지는 보이는 영역의 중앙)
    const vl = Math.max(r.left, 0), vr = Math.min(r.right, window.innerWidth);
    const vt = Math.max(r.top, 0), vb = Math.min(r.bottom, window.innerHeight);
    const left = Math.min(Math.max((vl + vr) / 2 - b.width / 2, 4), window.innerWidth - b.width - 4);
    const top = Math.min(Math.max((vt + vb) / 2 - b.height / 2, 4), window.innerHeight - b.height - 4);
    bubble.style.left = left + "px";
    bubble.style.top = top + "px";
  }

  function hide() {
    clearTimeout(showTimer);
    clearTimeout(hideTimer);
    bubble.classList.remove("show");
    current = null;
  }

  function say(text, isErr) {
    toast.textContent = text;
    toast.classList.toggle("err", !!isErr);
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
  }

  // ---- 이미지 → PNG Blob ----
  async function loadBlob(url) {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error("HTTP " + res.status);
      return await res.blob();
    } catch {
      if (!/^https?:/i.test(url)) throw new Error("이미지를 가져올 수 없습니다");
      const r = await chrome.runtime.sendMessage({ type: "fetch-image", url });
      if (!r?.ok) throw new Error(r?.error || "이미지를 가져올 수 없습니다");
      const bin = atob(r.base64);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return new Blob([bytes], { type: r.mime || "application/octet-stream" });
    }
  }

  async function toPng(blob) {
    if (blob.type === "image/png") return blob;
    const objUrl = URL.createObjectURL(blob);
    try {
      const im = new Image();
      im.src = objUrl;
      await im.decode();
      const c = document.createElement("canvas");
      c.width = im.naturalWidth || 1;
      c.height = im.naturalHeight || 1;
      c.getContext("2d").drawImage(im, 0, 0);
      return await new Promise((res, rej) =>
        c.toBlob((b) => (b ? res(b) : rej(new Error("PNG 변환 실패"))), "image/png")
      );
    } finally {
      URL.revokeObjectURL(objUrl);
    }
  }

  async function copyImage(img) {
    const url = img.currentSrc || img.src;
    // 클릭 제스처가 유지되도록 ClipboardItem에 Promise를 직접 전달
    const pngPromise = loadBlob(url).then(toPng);
    await navigator.clipboard.write([new ClipboardItem({ "image/png": pngPromise })]);
  }

  // ---- 이벤트 ----
  document.addEventListener(
    "mouseover",
    (e) => {
      const t = e.target;
      if (!isCandidate(t) || t === dismissed) return;
      clearTimeout(hideTimer);
      if (t === current) return;
      clearTimeout(showTimer);
      showTimer = setTimeout(() => {
        current = t;
        position(t);
      }, HOVER_DELAY);
    },
    true
  );

  document.addEventListener(
    "mouseout",
    (e) => {
      const t = e.target;
      if (t === dismissed) dismissed = null;
      if (t !== current && !(t instanceof HTMLImageElement)) return;
      clearTimeout(showTimer);
      clearTimeout(hideTimer);
      hideTimer = setTimeout(hide, HIDE_DELAY);
    },
    true
  );

  bubble.addEventListener("mouseenter", () => clearTimeout(hideTimer));
  bubble.addEventListener("mouseleave", () => {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(hide, HIDE_DELAY);
  });

  root.getElementById("ok").addEventListener("click", async () => {
    const img = current;
    dismissed = img;
    hide();
    if (!img) return;
    try {
      await copyImage(img);
      say("이미지를 클립보드에 복사했습니다");
    } catch (err) {
      say("복사 실패: " + (err?.message || err), true);
    }
  });

  // ---- 붙여넣기: 입력창에 포커스가 있고 클립보드에 이미지가 있을 때 ----
  const pbubble = root.getElementById("pbubble");
  let field = null; // 현재 포커스된 입력창
  let clipBlob = null; // 클립보드의 이미지

  const NON_TEXT = /^(button|checkbox|radio|submit|reset|file|image|color|range|hidden)$/i;
  const editableOf = (el) => {
    if (!(el instanceof HTMLElement)) return null;
    if (el instanceof HTMLTextAreaElement) return el;
    if (el instanceof HTMLInputElement) return NON_TEXT.test(el.type) ? null : el;
    if (el.isContentEditable) {
      let host = el;
      while (host.parentElement && host.parentElement.isContentEditable) host = host.parentElement;
      return host;
    }
    return null;
  };

  async function readClipboardImage() {
    try {
      const items = await navigator.clipboard.read();
      for (const it of items) {
        const type = it.types.find((t) => t.startsWith("image/"));
        if (type) return await it.getType(type);
      }
    } catch {
      /* 권한 거부 / 포커스 없음 / 이미지 아님 */
    }
    return null;
  }

  function positionPaste() {
    if (!field) return;
    const r = field.getBoundingClientRect();
    pbubble.classList.add("show");
    const b = pbubble.getBoundingClientRect();
    let top = r.top - b.height - 6;
    if (top < 4) top = r.top + 6;
    const left = Math.min(Math.max(r.right - b.width, 4), window.innerWidth - b.width - 4);
    pbubble.style.left = left + "px";
    pbubble.style.top = Math.min(top, window.innerHeight - b.height - 4) + "px";
  }

  function hidePaste() {
    pbubble.classList.remove("show");
    field = null;
    clipBlob = null;
  }

  async function checkPaste(el) {
    const blob = await readClipboardImage();
    if (!blob || document.activeElement == null || editableOf(document.activeElement) !== el) {
      if (field === el) hidePaste();
      return;
    }
    field = el;
    clipBlob = blob;
    positionPaste();
  }

  document.addEventListener(
    "focusin",
    (e) => {
      const el = editableOf(e.target);
      if (el) checkPaste(el);
    },
    true
  );

  document.addEventListener(
    "focusout",
    (e) => {
      if (editableOf(e.target) === field) hidePaste();
    },
    true
  );

  window.addEventListener("focus", () => {
    const el = editableOf(document.activeElement);
    if (el) checkPaste(el);
  });

  // 버튼을 눌러도 입력창 포커스가 유지되도록
  pbubble.addEventListener("mousedown", (e) => e.preventDefault());

  root.getElementById("paste").addEventListener("click", async () => {
    const el = field;
    const blob = clipBlob;
    if (!el || !blob) return;
    hidePaste();
    try {
      const png = blob.type === "image/png" ? blob : await toPng(blob);
      const dt = new DataTransfer();
      dt.items.add(new File([png], "image.png", { type: "image/png" }));
      el.focus();
      const ev = new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true });
      el.dispatchEvent(ev);
      if (ev.defaultPrevented) say("이미지를 붙여넣었습니다");
      else say("이 입력창은 이미지 붙여넣기를 지원하지 않을 수 있습니다", true);
    } catch (err) {
      say("붙여넣기 실패: " + (err?.message || err), true);
    }
  });

  const reposition = () => {
    if (current) position(current);
    if (field) positionPaste();
  };
  window.addEventListener("scroll", reposition, true);
  window.addEventListener("resize", reposition);
})();
