function sendToTab(tab, type) {
  if (tab?.id == null) return;
  chrome.tabs.sendMessage(tab.id, { type }).catch(() => {});
}

chrome.action.onClicked.addListener((tab) => sendToTab(tab, "capture-video"));

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "capture-video" && command !== "copy-video-url") return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  sendToTab(tab, command);
});

// ---- 스트리밍 주소 감지: 탭별로 m3u8(HLS) / mpd(DASH) 요청을 기록 ----
const STREAM_RE = /\.(m3u8|mpd)(?:[?#]|$)/i;
const key = (tabId) => "streams_" + tabId;

async function readStreams(tabId) {
  const data = await chrome.storage.session.get(key(tabId));
  return data[key(tabId)] || [];
}

// 같은 탭에서 동시에 여러 요청이 와도 덮어쓰지 않도록 순서대로 처리
let queue = Promise.resolve();
chrome.webRequest.onBeforeRequest.addListener(
  (d) => {
    if (d.tabId < 0 || !STREAM_RE.test(d.url)) return;
    queue = queue.then(async () => {
      const list = await readStreams(d.tabId);
      if (list.some((s) => s.url === d.url)) return;
      list.push({ url: d.url, type: /\.mpd/i.test(d.url.split(/[?#]/)[0]) ? "DASH(mpd)" : "HLS(m3u8)" });
      await chrome.storage.session.set({ [key(d.tabId)]: list.slice(-20) });
    });
  },
  { urls: ["<all_urls>"] }
);

// 페이지를 새로 불러오면 그 탭의 기록을 지운다
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status === "loading" && info.url) chrome.storage.session.remove(key(tabId));
});
chrome.tabs.onRemoved.addListener((tabId) => chrome.storage.session.remove(key(tabId)));

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type !== "get-streams" || sender.tab?.id == null) return;
  queue.then(() => readStreams(sender.tab.id)).then((streams) => sendResponse({ streams }));
  return true;
});
