(() => {
  const MIN_W = 120; // 이보다 작은 동영상은 무시
  const MIN_H = 70;

  const host = document.createElement("div");
  host.style.cssText = "all:initial;position:fixed;z-index:2147483647;top:0;left:0;";
  const root = host.attachShadow({ mode: "closed" });
  root.innerHTML = `
    <style>
      .btn{position:fixed;display:none;gap:8px}
      .btn.show{display:flex}
      .btn button{padding:8px 14px;border:0;border-radius:8px;cursor:pointer;
        background:#18181b;color:#fafafa;font:600 14px/1.2 system-ui,"Malgun Gothic",sans-serif;
        box-shadow:0 4px 16px rgba(0,0,0,.4)}
      .toast{position:fixed;right:16px;bottom:16px;display:none;padding:10px 14px;border-radius:10px;
        background:#18181b;color:#fafafa;font:13px/1.3 system-ui,"Malgun Gothic",sans-serif;
        box-shadow:0 4px 16px rgba(0,0,0,.35)}
      .toast.show{display:block}
      .toast.err{background:#b91c1c}
    </style>
    <div class="btn" id="btn">
      <button id="cap">캡처</button>
      <button id="url">주소 복사</button>
    </div>
    <div class="toast" id="toast"></div>`;
  const btn = root.getElementById("btn");
  const toast = root.getElementById("toast");
  document.documentElement.appendChild(host);

  let current = null;
  let toastTimer = 0;
  let ticking = false;

  function say(text, isErr) {
    toast.textContent = text;
    toast.classList.toggle("err", !!isErr);
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2500);
  }

  const inRect = (r, x, y) => x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;

  function videoAt(x, y) {
    let found = null;
    for (const v of document.querySelectorAll("video")) {
      const r = v.getBoundingClientRect();
      if (r.width < MIN_W || r.height < MIN_H || v.readyState < 2) continue;
      if (inRect(r, x, y)) found = v; // 나중 요소가 위에 있을 가능성이 높음
    }
    return found;
  }

  function place(v) {
    const r = v.getBoundingClientRect();
    btn.classList.add("show");
    const b = btn.getBoundingClientRect();
    const left = Math.min(Math.max(r.right - b.width - 12, 4), window.innerWidth - b.width - 4);
    const top = Math.min(Math.max(r.top + 12, 4), window.innerHeight - b.height - 4);
    btn.style.left = left + "px";
    btn.style.top = top + "px";
  }

  function hide() {
    btn.classList.remove("show");
    current = null;
  }

  document.addEventListener(
    "mousemove",
    (e) => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        ticking = false;
        if (e.composedPath()[0] === host || e.composedPath().includes(host)) return;
        const v = videoAt(e.clientX, e.clientY);
        if (!v) return hide();
        current = v;
        place(v);
      });
    },
    true
  );

  document.addEventListener("mouseleave", hide);
  window.addEventListener("scroll", () => current && place(current), true);
  window.addEventListener("resize", () => current && place(current));

  const pad = (n) => String(n).padStart(2, "0");
  const stamp = (sec) => {
    const s = Math.floor(sec);
    const t = `${pad(Math.floor(s / 3600))}${pad(Math.floor((s % 3600) / 60))}${pad(s % 60)}`;
    const ms = String(Math.round((sec - s) * 1000)).padStart(3, "0");
    return `${t}_${ms}`;
  };

  // 마우스 없이 캡처: 화면에 보이는 동영상 중 재생 중인 것(없으면 가장 큰 것)을 고른다
  function pickVideo() {
    let best = null;
    let bestScore = 0;
    for (const v of document.querySelectorAll("video")) {
      const r = v.getBoundingClientRect();
      if (r.width < MIN_W || r.height < MIN_H || v.readyState < 2) continue;
      const w = Math.min(r.right, window.innerWidth) - Math.max(r.left, 0);
      const h = Math.min(r.bottom, window.innerHeight) - Math.max(r.top, 0);
      if (w <= 0 || h <= 0) continue;
      const score = w * h * (v.paused ? 1 : 1000);
      if (score > bestScore) {
        best = v;
        bestScore = score;
      }
    }
    return best;
  }

  chrome.runtime.onMessage.addListener((msg) => {
    const v = pickVideo();
    if (!v) return;
    if (msg?.type === "capture-video") capture(v);
    else if (msg?.type === "copy-video-url") copyUrl(v);
  });

  root.getElementById("cap").addEventListener("click", () => current && capture(current));
  root.getElementById("url").addEventListener("click", () => current && copyUrl(current));

  // 동영상 파일 주소 찾기: video.currentSrc → <source> 순. blob:/data: 는 파일 주소가 아니므로 제외
  function videoUrl(v) {
    const cands = [v.currentSrc, v.src, ...[...v.querySelectorAll("source")].map((s) => s.src)];
    return cands.find((u) => /^https?:|^file:/i.test(u || "")) || null;
  }

  async function copyUrl(v) {
    let url = videoUrl(v);
    let note = "동영상 주소를 복사했습니다";
    if (!url) {
      // blob: 등 → 이 탭에서 감지된 스트리밍 주소(m3u8/mpd)를 사용
      let streams = [];
      try {
        streams = (await chrome.runtime.sendMessage({ type: "get-streams" }))?.streams || [];
      } catch {}
      if (!streams.length) {
        return say("파일 주소도, 감지된 스트리밍 주소(m3u8/mpd)도 없습니다", true);
      }
      url = streams[0].url; // 가장 먼저 요청된 것 = 보통 마스터 목록
      note = `스트리밍 주소(${streams[0].type})를 복사했습니다` + (streams.length > 1 ? ` · 총 ${streams.length}개 감지` : "");
    }
    try {
      await navigator.clipboard.writeText(url);
      say(note);
    } catch {
      const t = document.createElement("textarea");
      t.value = url;
      t.style.cssText = "position:fixed;opacity:0";
      document.body.appendChild(t);
      t.select();
      const ok = document.execCommand("copy");
      t.remove();
      say(ok ? note : "복사 실패: " + url, !ok);
    }
  }

  function capture(v) {
    try {
      if (!v.videoWidth || !v.videoHeight) throw new Error("재생 중인 화면이 없습니다");
      const c = document.createElement("canvas");
      c.width = v.videoWidth;
      c.height = v.videoHeight;
      c.getContext("2d").drawImage(v, 0, 0, c.width, c.height);
      c.toBlob((blob) => {
        if (!blob) return say("캡처 실패: 이미지를 만들 수 없습니다", true);
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = `capture_${stamp(v.currentTime)}.png`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(a.href), 10000);
        say("화면을 PNG로 저장했습니다");
      }, "image/png");
    } catch (err) {
      const blocked = err?.name === "SecurityError";
      say(blocked ? "이 동영상은 보호되어 있어 캡처할 수 없습니다" : "캡처 실패: " + (err?.message || err), true);
    }
  }
})();
